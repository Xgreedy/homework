I have not generated visible packet traffic to test my CS680 homework #10 so the incoming and outgoing packets are all zero. I think the reason is current Linux Kernel
handles packets very quickly so we cannot catch them. If we want to see incoming and outgoing packets there, the system needs to burden packet traffic heavily.


Weiwei Jia
