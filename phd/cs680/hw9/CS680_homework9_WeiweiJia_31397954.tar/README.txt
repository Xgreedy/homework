In my experiment virtual machine, it only has one CPU. My experiment kernel version is the latest
stable one 4.5.1.

In CS680_homework9_WeiweiJia_31397954_IO.png, I add I/O requests by 'dd' command so that the Block softirq counts
are increased quickly.

Weiwei Jia <wj47@njit.edu>
April 17th, 2016.
